# nehne 新アイコン導入手順（書き換え済み版）

## このパックの中身

```
index.html                           ← 書き換え済み！ そのまま上書きアップするだけ
manifest.json                        ← リポジトリの一番上に置く
icons/                               ← フォルダごとアップ
  icon-192.png / icon-512.png        （ランチャー用）
  maskable-192.png / maskable-512.png（アダプティブ用・丸/角丸で欠けない）
  apple-touch-icon.png               （iOS用 180x180）
  favicon-32.png                     （ブラウザタブ用）
PlayConsole用_ストアアイコン512.png   ← GitHubには入れない。後日 Play Console 用
```

## やること（1回のアップロードだけ）

index.html は **すでに新アイコン参照に書き換え済み** です。手作業の編集は不要。

1. github.com にログイン → `santos7227-commits/nehne-app` を開く
2. 「Add file」→「Upload files」
3. `index.html`・`manifest.json`・`icons` フォルダの中身6枚 をまとめてドロップ
   （index.html は既存を上書きします）
4. 「Commit changes」

※ sw.js はネットワーク優先方式なので変更不要。ファイルを置き換えるだけで
   自動的に新しいものが配信されます。

## 確認

1. スマホの Chrome で https://santos7227-commits.github.io/nehne-app/ を開く
2. 一度ホーム画面のアイコンを削除 → 再度「ホーム画面に追加」
3. リボン付きボトルのアイコンが出れば成功

## 微調整

実機で見て気になる点（リボンの大きさ・色・キラキラの量など）を
そのまま Claude に伝えてください。調整版を作り直します。
